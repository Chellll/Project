<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['form_name']) && $_POST['form_name'] == 'logoutform')
{
   if (session_id() == "")
   {
      session_start();
   }
   unset($_SESSION['username']);
   unset($_SESSION['fullname']);
   header('Location: ./index.php');
   exit;
}
?>
<!doctype html>
<html>
<head>
<style>
   .rightpic {
    float: right; /* Выравнивание по правому краю */
   margin: 20px;
   }
   body {
    background-image: url(images/bg3.jpg); /* Путь к фоновому изображению */
	background-size: cover;
    background-color: #c7b39b; /* Цвет фона */
   }
  </style>
<meta charset="utf-8">
<title>Безымянная страница</title>
<meta name="generator" content="WYSIWYG Web Builder 14 - http://www.wysiwygwebbuilder.com">
<link href="first.css" rel="stylesheet">
<link href="prof_admin.css" rel="stylesheet">
</head>
<body>
      <p><img src="images/rosa.png" alt="Иллюстрация" 
   width="300" height="300" class="rightpic"></p> 
<div id="wb_Logout1" style="position:absolute;left:128px;top:431px;width:200px;height:50px;z-index:1;">
<form name="logoutform" method="post" action="<?php echo basename(__FILE__); ?>" id="logoutform">
<input type="hidden" name="form_name" value="logoutform">
<input type="submit" name="logout" value="Logout" id="Logout1">
</form>
</div>
<input type="submit" id="Button2" onclick="window.location.href='./map_1.php';return false;" name="" value="Карта" style="position:absolute;left:120px;top:100px;width:200px;height:50px;z-index:3;">
<input type="submit" id="Button5" onclick="window.location.href='./parser.php';return false;" name="" value="ПарсерТендер" style="position:absolute;left:120px;top:160px;width:200px;height:50px;z-index:6;">
<input type="submit" id="Button3" onclick="window.location.href='./parser2.php';return false;" name="" value="ПарсерHHru" style="position:absolute;left:120px;top:220px;width:200px;height:50px;z-index:6;">
<input type="submit" id="Button6" onclick="window.location.href='./otzov.php';return false;" name="" value="Отзывы" style="position:absolute;left:120px;top:280px;width:200px;height:50px;z-index:7;">
<input type="submit" id="Button4" onclick="window.location.href='./parser_sravnenie.php';return false;" name="" value="Сравнение" style="position:absolute;left:120px;top:340px;width:200px;height:50px;z-index:7;">
</body>
</html>