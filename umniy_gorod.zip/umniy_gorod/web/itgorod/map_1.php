


<!DOCTYPE HTML>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <script src="http://cdn.leafletjs.com/leaflet/v0.7.7/leaflet.js"></script>
	<script src="jquery.min.js"></script>
	<script src="analiz.js"></script>
    <link rel="stylesheet" href="http://cdn.leafletjs.com/leaflet/v0.7.7/leaflet.css" />
    <style>
      html, body {
        height: 100%;
        padding: 0;
        margin: 0;
      }
      #map {
        /* configure the size of the map */
        width: 98%;
        height:95%;
      }
	  .switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

/* Hide default HTML checkbox */
.switch input {display:none;}

/* The slider */
.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
    </style>
  </head>
  <body>
  Плотность населения
<select id="select1" name="select1">
  <option value="0">Выкл</option>
  <option value="1">Вкл</option>
</select>
Проходимость улиц

<select id="select2" name="select2">
  <option value="0">Выкл</option>
  <option value="1">Вкл</option>
</select>
Пробки

<select id="select3" name="select3">
  <option value="0">Выкл</option>
  <option value="1">Вкл</option>
</select>
Отзывы
<td>
<select id="select4" name="select4">
  <option value="0">Выкл</option>
  <option value="1">Вкл</option>
</select>
Приоритетность расставления велодорог распределена по цвету: Красныйм -> Желтый -> Зеленый -> Голубой -> Белый
<script>
    document.getElementById("select1").onchange = function() {
     localStorage['select1'] = document.getElementById("select1").value;
    }
	document.getElementById("select2").onchange = function() {
     localStorage['select2'] = document.getElementById("select2").value;
    }
	document.getElementById("select3").onchange = function() {
     localStorage['select3'] = document.getElementById("select3").value;
    }
	document.getElementById("select4").onchange = function() {
     localStorage['select4'] = document.getElementById("select4").value;
    }

    window.onload= function(){
        if(localStorage['select1'])
            document.getElementById("select1").value = localStorage['select1'];
		if(localStorage['select2'])
            document.getElementById("select2").value = localStorage['select2'];
		if(localStorage['select3'])
            document.getElementById("select3").value = localStorage['select3'];
		if(localStorage['select4'])
            document.getElementById("select4").value = localStorage['select4'];
    }

</script>
	<script>

	var color;
	
	var selected1 =Number(localStorage['select1']);
	var selected2 =Number(localStorage['select2']);
	var selected3 =Number(localStorage['select3']);
	var selected4 =Number(localStorage['select4']);
	var summ = selected1+selected2+selected3+selected4;
	//$('#otrk_key').text(summ);
	function collorest(num1, num2, num3, num4, num5){
		
		var sum = num1*selected1 + num2*selected2 +num3*selected3 + num4*selected4;
		

		if(sum==4)
			color='red';
		if(sum==3)
			color='yellow';
		if(sum==2)
			color='green';
		if(sum==1)
			color='blue';
		if(sum==0)
			color='purple';
	}
	
	
	</script>
<input id="btn_select" type="submit" value="Выбрать" class="form-control" style="margin: 0px 0px 0px 0px; width: 365px; height: 30px; padding: 5px;">
    <div id="map"></div>
    <script>
     
	// document.write("Text: " + firstLanguage.text + "<br/>");
	 
	 // initialize Leaflet
	  var weight_point =4;
	  var opacity_point =0.5;
	  var smoothFactor_point = 1;
		//var color = 'blue';
      var map = L.map('map').setView([55.798551, 49.106324], 12);

      // add the OpenStreetMap tiles
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; <a href="https://openstreetmap.org/copyright">OpenStreetMap contributors</a>'
      }).addTo(map);

      // show the scale bar on the lower left corner
      L.control.scale().addTo(map);
	  
/* 
	  var for_stoyank;
	  var for_prohod;
	  var for_plotnost;
	  var for_probk;
	  var for_otz; */
	  
//30 лет Победы
    var pointA = new L.LatLng(57.12878649751151, 65.55996894836427);
	var pointB = new L.LatLng(57.10860977347526, 65.61181068420412);
	for_prohod=0;
	for_plotnost=1;
	for_probk=0;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
	//collorest();
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//50 лет Октября
    var pointA = new L.LatLng(57.155190672549146, 65.56177139282228);
	var pointB = new L.LatLng(57.128611803862896, 65.61316251770505);
	for_prohod=1;
	for_plotnost=0;
	for_probk=1;
	for_otz=1;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Барнаульская
    var pointA = new L.LatLng(57.1676178610119, 65.44821739196779);
	var pointB = new L.LatLng(57.16491867700474, 65.47619819641115);
	for_prohod=0;
	for_plotnost=0;
	for_probk=0;
	for_otz=1;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Вербная
    var pointA = new L.LatLng(57.12154184869132, 65.6252431869507);
	var pointB = new L.LatLng(57.124453855385966, 65.64146518707277);
	for_prohod=0;
	for_plotnost=0;
	for_probk=0;
	for_otz=1;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Волгоградская
    var pointA = new L.LatLng(57.14792791033971, 65.49997329711915);
	var pointB = new L.LatLng(57.141886161319654, 65.52831888198854);
	for_prohod=0;
	for_plotnost=0;
	for_probk=0;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Газовиков
    var pointA = new L.LatLng(57.17801718437182, 65.54730892181398);
	var pointB = new L.LatLng(57.17115442454485, 65.5700969696045);
	for_prohod=0;
	for_plotnost=1;
	for_probk=0;
	for_otz=1;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Герцена
    var pointA = new L.LatLng(57.15686649211189, 65.52400588989259);
	var pointB = new L.LatLng(57.146181841457135, 65.54451942443849);
	for_prohod=0;
	for_plotnost=0;
	for_probk=0;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Григория Алексеева
    var pointA = new L.LatLng(57.21686660138623, 65.58443069458009);
	var pointB = new L.LatLng(57.20459543921517, 65.55687904357912);
	for_prohod=0;
	for_plotnost=0;
	for_probk=0;
	for_otz=1;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Домостроителей
    var pointA = new L.LatLng(57.155749287506616, 65.65412521362306);
	var pointB = new L.LatLng(57.157192337098465, 65.6851100921631);
	for_prohod=0;
	for_plotnost=0;
	for_probk=0;
	for_otz=1;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Дружбы
    var pointA = new L.LatLng(57.17124748743748, 65.68021774291994);
	var pointB = new L.LatLng(57.183297152416394, 65.55687904357912);
	for_prohod=0;
	for_plotnost=0;
	for_probk=0;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Ленина
    var pointA = new L.LatLng(57.16213784603305, 65.51937103271486);
	var pointB = new L.LatLng(57.14690938017208, 65.54816722869874);
	for_prohod=1;
	for_plotnost=0;
	for_probk=1;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Малыгина
    var pointA = new L.LatLng(57.14564636382377, 65.54460525512697);
	var pointB = new L.LatLng(57.135121491575774, 65.56511878967287);
	for_prohod=0;
	for_plotnost=0;
	for_probk=1;
	for_otz=1;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Мельникайте 1
    var pointA = new L.LatLng(57.13223361402543, 65.56228637695314);
	var pointB = new L.LatLng(57.154119970299, 65.59747695922853);
	for_prohod=1;
	for_plotnost=0;
	for_probk=1;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Мельникайте 2
    var pointA = new L.LatLng(57.154119970299, 65.59747695922853);
	var pointB = new L.LatLng(57.177389120346426, 65.60348510742189);
	for_prohod=1;
	for_plotnost=0;
	for_probk=0;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Мельникайте 3
    var pointA = new L.LatLng(57.133118632699926, 65.5639171600342);
	var pointB = new L.LatLng(57.114342385476796, 65.53906917572023);
	for_prohod=1;
	for_plotnost=0;
	for_probk=0;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Монтажников
    var pointA = new L.LatLng(57.09763144371703, 65.58378696441652);
	var pointB = new L.LatLng(57.12168163024433, 65.61618804931642);
	for_prohod=0;
	for_plotnost=0;
	for_probk=0;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Мориса Тореза
    var pointA = new L.LatLng(57.14334139336954, 65.5384683609009);
	var pointB = new L.LatLng(57.14769510591624, 65.55074214935304);	
	for_prohod=1;
	for_plotnost=0;
	for_probk=1;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Московский Тракт
    var pointA = new L.LatLng(57.11219858563151, 65.40779113769533);
	var pointB = new L.LatLng(57.12976476589593, 65.48134803771974);
	for_prohod=0;
	for_plotnost=1;
	for_probk=1;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Николая Чаплина
    var pointA = new L.LatLng(57.12158844260093, 65.54241657257081);
	var pointB = new L.LatLng(57.120784689444214, 65.54730892181398);
	for_prohod=0;
	for_plotnost=0;
	for_probk=0;
	for_otz=1;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Одесская
    var pointA = new L.LatLng(57.13525539978692, 65.574688911438);
	var pointB = new L.LatLng(57.1532936462865, 65.60575962066652);
	for_prohod=0;
	for_plotnost=0;
	for_probk=0;
	for_otz=1;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Одесская
    var pointA = new L.LatLng(57.13525539978692, 65.574688911438);
	var pointB = new L.LatLng(57.1532936462865, 65.60575962066652);
	for_prohod=0;
	for_plotnost=0;
	for_probk=0;
	for_otz=1;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Орджоникидзе
    var pointA = new L.LatLng(57.14743028910367, 65.53823232650758);
	var pointB = new L.LatLng(57.15452730632939, 65.55001258850099);
		for_prohod=1;
	for_plotnost=1;
	for_probk=1;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Осипенко 1
    var pointA = new L.LatLng(57.15535360278323, 65.56164264678956);
	var pointB = new L.LatLng(57.15877497191333, 65.55314540863039);
	for_prohod=0;
	for_plotnost=0;
	for_probk=0;
	for_otz=1;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Осипенко 2
    var pointA = new L.LatLng(57.15877497191333, 65.55314540863039);
	var pointB = new L.LatLng(57.159938630776885, 65.54203033447267);
	for_prohod=0;
	for_plotnost=0;
	for_probk=0;
	for_otz=1;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Первомайская 1
    var pointA = new L.LatLng(57.15996772177936, 65.54204106330873);
	var pointB = new L.LatLng(57.15616824318823, 65.540828704834);
	for_prohod=0;
	for_plotnost=0;
	for_probk=0;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Первомайская 2
    var pointA = new L.LatLng(57.15616824318823, 65.540828704834);
	var pointB = new L.LatLng(57.14913846972837, 65.52640914916994);
	for_prohod=0;
	for_plotnost=0;
	for_probk=0;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Пермякова 1
    var pointA = new L.LatLng(57.104857461810695, 65.56181430816652);
	var pointB = new L.LatLng(57.127249166398066, 65.59000968933107);
	for_prohod=1;
	for_plotnost=1;
	for_probk=1;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Пермякова 2
    var pointA = new L.LatLng(57.127249166398066, 65.59000968933107);
	var pointB = new L.LatLng(57.13396869650545, 65.60354948043825);
	for_prohod=1;
	for_plotnost=0;
	for_probk=1;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Профсоюзная 1
    var pointA = new L.LatLng(57.18083171057066, 65.57327270507814);
	var pointB = new L.LatLng(57.157564727853675, 65.56606292724611);
	for_prohod=1;
	for_plotnost=0;
	for_probk=1;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Профсоюзная 2
    var pointA = new L.LatLng(57.157564727853675, 65.56606292724611);
	var pointB = new L.LatLng(57.136798220319456, 65.52555084228517);
	for_prohod=1;
	for_plotnost=0;
	for_probk=1;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Республики 1
    var pointA = new L.LatLng(57.163208316185475, 65.52044391632081);
	var pointB = new L.LatLng(57.12664353358557, 65.59078216552736);
	for_prohod=1;
	for_plotnost=1;
	for_probk=0;
	for_otz=1;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Республики 2
    var pointA = new L.LatLng(57.12664353358557, 65.59078216552736);
	var pointB = new L.LatLng(57.09411116336663, 65.68056106567384);
	for_prohod=1;
	for_plotnost=0;
	for_probk=0;
	for_otz=1;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Холодильная
    var pointA = new L.LatLng(57.13633246995383, 65.5524265766144);
	var pointB = new L.LatLng(57.15430618161233, 65.584774017334);
	for_prohod=0;
	for_plotnost=1;
	for_probk=0;
	for_otz=1;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Челюскинцев
    var pointA = new L.LatLng(57.154061779071334, 65.52922010421754);
	var pointB = new L.LatLng(57.16073862500617, 65.54080188274385);
	for_prohod=0;
	for_plotnost=0;
	for_probk=0;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Широтная 1
    var pointA = new L.LatLng(57.09307366598059, 65.62863349914552);
	var pointB = new L.LatLng(57.114109369763675, 65.57327270507814);
	for_prohod=0;
	for_plotnost=0;
	for_probk=0;
	for_otz=1;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Широтная 2
    var pointA = new L.LatLng(57.114109369763675, 65.57327270507814);
	var pointB = new L.LatLng(57.12054006545603, 65.54735183715822);
	for_prohod=0;
	for_plotnost=0;
	for_probk=0;
	for_otz=1;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Ямская 1
    var pointA = new L.LatLng(57.168129752990176, 65.5144786834717);
	var pointB = new L.LatLng(57.15834440885369, 65.48613309860231);
	for_prohod=0;
	for_plotnost=1;
	for_probk=0;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Ямская 2
    var pointA = new L.LatLng(57.15834440885369, 65.48613309860231);
	var pointB = new L.LatLng(57.162033124462766, 65.43899059295656);
	for_prohod=0;
	for_plotnost=1;
	for_probk=1;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Николая Чаплина 1
    var pointA = new L.LatLng(57.14116434499139, 65.53426265716554);
	var pointB = new L.LatLng(57.12163503645194, 65.5419445037842);
	for_prohod=0;
	for_plotnost=0;
	for_probk=1;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Николая Чаплина 2
    var pointA = new L.LatLng(57.12163503645194, 65.5419445037842);
	var pointB = new L.LatLng(57.120889527801666, 65.54773807525636);
	for_prohod=0;
	for_plotnost=0;
	for_probk=1;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Щербакова 1
    var pointA = new L.LatLng(57.17343439796769, 65.53851127624513);
	var pointB = new L.LatLng(57.18478564143342, 65.55825233459474);
	for_prohod=0;
	for_plotnost=0;
	for_probk=1;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Щербакова 2
    var pointA = new L.LatLng(57.18478564143342, 65.55825233459474);
	var pointB = new L.LatLng(57.20900004727329, 65.62279701232912);
	for_prohod=0;
	for_plotnost=0;
	for_probk=1;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//2 Луговая
    var pointA = new L.LatLng(57.172852785456236, 65.5384683609009);
	var pointB = new L.LatLng(57.160985892448515, 65.54168701171876);
	for_prohod=0;
	for_plotnost=0;
	for_probk=1;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Закалужская 1
    var pointA = new L.LatLng(57.129578431053595, 65.48177719116212);
	var pointB = new L.LatLng(57.1197013423732, 65.52022933959962);
	for_prohod=0;
	for_plotnost=0;
	for_probk=1;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Закалужская 2
    var pointA = new L.LatLng(57.1197013423732, 65.52022933959962);
	var pointB = new L.LatLng(57.07456869716714, 65.64382553100587);
	for_prohod=0;
	for_plotnost=0;
	for_probk=1;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Благовещенский взвос
    var pointA = new L.LatLng(57.16808321764867, 65.5144786834717);
	var pointB = new L.LatLng(57.16359228162352, 65.51980018615724);
	for_prohod=0;
	for_plotnost=0;
	for_probk=1;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Червишевский
    var pointA = new L.LatLng(57.12009740841799, 65.51881313323976);
	var pointB = new L.LatLng(57.13640233288228, 65.5272674560547);
	for_prohod=0;
	for_plotnost=0;
	for_probk=1;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);

//Николая Федорова
    var pointA = new L.LatLng(57.10904091538474, 65.55081725120546);
	var pointB = new L.LatLng(57.12498963967628, 65.57095527648927);
	for_prohod=0;
	for_plotnost=0;
	for_probk=1;
	for_otz=0;
	collorest(for_prohod, for_plotnost, for_probk, for_otz);
	var pointList = [pointA, pointB];
	var firstpolyline = new L.Polyline(pointList, {
    color: color,
    weight: weight_point,
    opacity: opacity_point,
    smoothFactor: smoothFactor_point});
firstpolyline.addTo(map);
   </script>
	<div id="otrk_key" style="padding: 10px;"></div></td>
 </body>
</html>

