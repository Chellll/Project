<?php

$mysqli = new mysqli("localhost", "Admiral", "123qwe", "bisycle_bd");
$mysqli->query("SET NAMES utf8");

$query = "SELECT id, name, street, kom FROM otzov";
if ($result = $mysqli->query($query)) {
	

    /* извлечение ассоциативного массива */
    while ($row = $result->fetch_assoc()) {
        printf ("%d - %s - %s - %s \n",$row["id"],  $row["name"], $row["street"], $row["kom"]);
		echo '<div>';
    }

    /* удаление выборки */
    $result->free();
}

?>


<!doctype html>

<html>
<head>
<meta charset="utf-8">
<title>Безымянная страница</title>
<style>
   body {
    background-image: url(images/bg.jpg); /* Путь к фоновому изображению */
    background-color: #c7b39b; /* Цвет фона */
   }
  </style>
<meta name="generator" content="WYSIWYG Web Builder 14 - http://www.wysiwygwebbuilder.com">
<link href="first.css" rel="stylesheet">
<link href="studenttss.css" rel="stylesheet">
</head>
<body>
<input type="submit" id="Button1" onclick="window.location.href='./prof_admin.php';return false;" name="" value="Назад" style="position:absolute;left:460px;top:375px;width:96px;height:25px;z-index:0;">
<input type="submit" id="Button1" onclick="window.location.href='./otzov_dob.php';return false;" name="" value="Добавить" style="position:absolute;left:460px;top:315px;width:96px;height:25px;z-index:0;">
</body>
</html>