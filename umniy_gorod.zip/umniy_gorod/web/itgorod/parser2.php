<html lang="ru"><head>
        <meta charset="utf-8">
</html>
<?php
header('Content-type: text/html; charset=utf-8');
require 'phpQuery.php';
set_time_limit(300);

function print_arr($arr){
	$arr = str_replace(array(" ", chr(0xC2).chr(0xA0)), '', $arr);
	$pieces = explode("вакансий", $arr);
	$qwe = $pieces[0];
	echo 'Число вакансий в Казани связанных с информационной безопасностью = ' . $qwe;
}

$url ="https://hh.ru/search/vacancy?L_is_autosearch=false&area=88&clusters=true&enable_snippets=true&no_magic=true&text=%D0%98%D0%BD%D1%84%D0%BE%D1%80%D0%BC%D0%B0%D1%86%D0%B8%D0%BE%D0%BD%D0%BD%D0%B0%D1%8F+%D0%B1%D0%B5%D0%B7%D0%BE%D0%BF%D0%B0%D1%81%D0%BD%D0%BE%D1%81%D1%82%D1%8C&page=0";
$file = file_get_contents($url);
$doc = phpQuery::newDocument($file);
foreach($doc->find('.bloko-gap_m-bottom') as $article){
		$article = pq($article);
		$text = $article ->find('.bloko-header-1')->html();
		if (!empty($text)){
			print_arr($text);
		}

	}
	
?>