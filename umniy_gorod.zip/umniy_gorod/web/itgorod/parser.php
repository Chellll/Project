<html lang="ru"><head>
        <meta charset="utf-8">
</html>
<?php
header('Content-type: text/html; charset=utf-8');
require 'phpQuery.php';
set_time_limit(300);
function print_arr($arr, $ind){
	echo '<pre>' . print_r($ind, true).print_r($arr, true) . '</pre>';
}

function parser($url, $ind){
	
	$file = file_get_contents($url);
	$doc = phpQuery::newDocument($file);
	foreach($doc->find('.advanced-table .tender-info') as $article){
		$article = pq($article);
		$text = $article ->find('.description')->html();
		if (!empty($text)){
			$ind = $ind+1;
			print_arr($text, $ind);
		}

	}
	
	return $ind;
	
} 
//Казань 4G:
//$url_f ="http://rostender.info/extsearch/advanced?query=aa2298ef2394c900a57840deab40cef1&page=";
//Казань Инфобез rostender.info:
//$url_f ="http://rostender.info/extsearch/advanced?query=a833cc60639a11344331c72c74cd03b1&page=";
//Казань Инфобез hh.ru:
//$url ="https://hh.ru/search/vacancy?L_is_autosearch=false&area=88&clusters=true&enable_snippets=true&no_magic=true&text=%D0%98%D0%BD%D1%84%D0%BE%D1%80%D0%BC%D0%B0%D1%86%D0%B8%D0%BE%D0%BD%D0%BD%D0%B0%D1%8F+%D0%B1%D0%B5%D0%B7%D0%BE%D0%BF%D0%B0%D1%81%D0%BD%D0%BE%D1%81%D1%82%D1%8C&page=0";

//Екатеренбург 4G:
//$url_f ="";
//Екатеренбург Инфобез rostender.info:
//$url_f ="http://rostender.info/extsearch/advanced?query=4612958b64d7b83d292948ca64732a71&page=";
//Екатеренбург Инфобез hh.ru:
//$url ="https://hh.ru/search/vacancy?L_is_autosearch=false&area=3&clusters=true&enable_snippets=true&no_magic=true&text=%D0%98%D0%BD%D1%84%D0%BE%D1%80%D0%BC%D0%B0%D1%86%D0%B8%D0%BE%D0%BD%D0%BD%D0%B0%D1%8F+%D0%B1%D0%B5%D0%B7%D0%BE%D0%BF%D0%B0%D1%81%D0%BD%D0%BE%D1%81%D1%82%D1%8C&page=0";

//Нижний Новгород 4G:
//$url_f ="http://rostender.info/extsearch/advanced?query=3fa87074a3004e23ddf78fb5fd343fc2&page=";
//Нижний Новгород Инфобез rostender.info:
//$url_f ="http://rostender.info/extsearch/advanced?query=5426c51180f856a7620577ee5cf8e70e&page=";
//Нижний Новгород Инфобез hh.ru:
//$url ="https://hh.ru/search/vacancy?L_is_autosearch=false&area=66&clusters=true&enable_snippets=true&no_magic=true&text=%D0%98%D0%BD%D1%84%D0%BE%D1%80%D0%BC%D0%B0%D1%86%D0%B8%D0%BE%D0%BD%D0%BD%D0%B0%D1%8F+%D0%B1%D0%B5%D0%B7%D0%BE%D0%BF%D0%B0%D1%81%D0%BD%D0%BE%D1%81%D1%82%D1%8C&page=0";

$url_f ="http://rostender.info/extsearch/advanced?query=a833cc60639a11344331c72c74cd03b1&page=";
$n = 1;

for($ind=0; $n!=12; $n++){
	$url = $url_f . $n;
	$ind = parser($url, $ind);
	echo $n;
}

echo $ind;

?>