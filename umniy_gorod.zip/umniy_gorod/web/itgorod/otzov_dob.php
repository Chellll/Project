
<?php
$mysqli = new mysqli("localhost", "Admiral", "123qwe", "bisycle_bd");
$mysqli->query("SET NAMES utf8"); /* соединение с БД */


if( isset( $_POST['c'] ) )
{
	$b= $_POST['b'];
	$c= $_POST['c'];
	$d= $_POST['d'];
	$mysqli->query("INSERT INTO `otzov` (`id`, `name`, `street`, `kom`) VALUES (NULL, '$b', '$c', '$d')");
	
	
	echo $b;
}

?>


<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Безымянная страница</title>
<style>
   body {
    background-image: url(images/bg.jpg); /* Путь к фоновому изображению */
    background-color: #c7b39b; /* Цвет фона */
   }
  </style>
<meta name="generator" content="WYSIWYG Web Builder 14 - http://www.wysiwygwebbuilder.com">
<link href="first.css" rel="stylesheet">
<link href="sudents_dob.css" rel="stylesheet">
</head>
<body>
<form name="authForm" method="POST" action="<?=$_SERVER['PHP_SELF']?>">
Имя пользователя:<input type="text" name="b"><br>
Улица:<input type="text" name="c"><br>
Что произошло:<input type="text" name="d"><br>
<input type="submit" value="Далее">
<input type="submit" id="Button1" onclick="window.location.href='./otzov.php';return false;" name="" value="Назад" style="position:absolute;left:483px;top:295px;width:96px;height:25px;z-index:0;">
</body>
</html>