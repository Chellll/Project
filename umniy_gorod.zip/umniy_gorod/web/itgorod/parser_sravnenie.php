<html lang="ru"><head>
        <meta charset="utf-8">
		<style type="text/css">
   .rightpic {
    float: right; /* Выравнивание по правому краю */
   margin: 20px;
   }
   body {
    background-image: url(images/bg3.jpg); /* Путь к фоновому изображению */
	background-size: cover;
    background-color: #c7b39b; /* Цвет фона */
   }
   TABLE {
    background: #dc0; /* Цвет фона таблицы */
    border: 5px double #000; /* Рамка вокруг таблицы */
	margin: 100px 20px;
   }
   TD, TH {
    padding: 5px; /* Поля вокруг текста */
    border: 1px solid #fff; /* Рамка вокруг ячеек */
   }
   #Button1
{
   border: 1px solid #2E6DA4;
   border-radius: 4px;
   background-color: #3370B7;
   background-image: none;
   color: #FFFFFF;
   font-family: Arial;
   font-weight: normal;
   font-size: 13px;
   margin: 0;
}
  </style>
</html>
<?php
$mysqli = new mysqli("localhost", "Admiral", "123qwe", "it_city");
$mysqli->query("SET NAMES utf8");

$query = "SELECT id, name, chislo_hh, chislo_tend, 4g FROM sravnenie";
if ($result = $mysqli->query($query)) {
	

    /* извлечение ассоциативного массива */
	echo "<table><tr><th>Id</th><th>Город</th><th>Вакансии ИБ</th><th>Реализованных тендров ИБ</th><th>Реализованные 4G тендеры</th></tr>";
	while ($row = mysqli_fetch_row($result)) {
		echo "<tr>";
        for ($j = 0 ; $j < 5 ; ++$j) echo "<td>$row[$j]</td>";
		echo "</tr>";
}
    // while ($row = $result->fetch_assoc()) {
        // printf ("%d - %s - %d - %d - %d \n",$row["id"],  $row["name"], $row["chislo_hh"], $row["chislo_tend"], $row["4g"]);
		// echo '<div>';
    // }

    /* удаление выборки */
    $result->free();
}
?>
<body>
      <p><img src="images/rosa.png" alt="Иллюстрация" 
   width="300" height="300" class="rightpic"></p>
   <input type="submit" id="Button1" onclick="window.location.href='./prof_admin.php';return false;" name="" value="Назад" style="position:absolute;left:30px;top:300px;width:200px;height:50px;z-index:7;">
</body>   